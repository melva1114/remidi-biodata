<title>Kelola Agama</title>
<style> *{
        text-decoration: none;
    }
    body{
        background-image: url(<?php echo "background.png";?>);
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
    }
     .bd{
        display: flex;
        height: 100vh;
        justify-content: center;
        align-items: center;
        background-color: rgb(148, 148, 148);
        font-family: Arial, Helvetica, sans-serif;
    }
    .box{
        width: 300px;
        min-height: 350px;
        border: 1px  rgb(253, 223, 0) solid;
        border-radius: 12px;
        background-color: purple;
        padding: 15px;
        box-sizing: border-box;
    }
    .box h2{
        margin-bottom: 20px;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
    }
    .input{
        width: 100%;
        padding: 10px;
        margin-bottom: 40px;
        box-sizing: border-box;
    }
    .btn{
        padding: 8px 15px;
        background-color: rgb(253, 223, 0);
        color: black;
        border: none;
        cursor: pointer;
        margin-bottom: 0px;
    }
    .btn a{
        color: black;
    }</style>
<body class="bd">
<form method="POST" enctype="multipart/form-data" class="box">
    <h2>ID</h2>
    <input type="number" name="id" placeholder="ID">
    <h2>Nama Agama</h2>
    <input type="number" name="nm_agama" placeholder="Nama Agama">
    <br><br>
    <input type="submit" name="konfirmasi" value="Konfirmasi" class="btn">
    <button class="btn"><a href="\melva\tampildata.php">Kembali</a></button>
</form>
</body>
<?php
include 'konek.php';
if (isset($_POST['konfirmasi'])){
    mysqli_query($koneksi, "insert into agama set idagama='$_POST[id]', nm_agama='$_POST[nm_agama]'");
}
?>