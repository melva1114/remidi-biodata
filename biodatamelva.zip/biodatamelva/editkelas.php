<title>Edit Agama</title>
<?php 
include 'konek.php';
if (isset($_GET['id'])) {
    $data = mysqli_query($koneksi, "SELECT * FROM agama WHERE idagama = '$_GET[id]'");
    $row = mysqli_fetch_assoc($data);
}
?>
<style>
    *{
        text-decoration: none;
    }
    body{
        background-image: url(<?php echo "background.png";?>);
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
    }
     .bd{
        display: flex;
        height: 100vh;
        justify-content: center;
        align-items: center;
        background-color: rgb(148, 148, 148);
        font-family: Arial, Helvetica, sans-serif;
    }
    .box{
        width: 300px;
        min-height: 350px;
        border: 1px  rgb(253, 223, 0) solid;
        border-radius: 12px;
        background-color: purple;
        padding: 15px;
        box-sizing: border-box;
    }
    .box h2{
        margin-bottom: 20px;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
    }
    .input{
        width: 100%;
        padding: 10px;
        margin-bottom: 40px;
        box-sizing: border-box;
    }
    .btn{
        padding: 8px 15px;
        background-color: rgb(253, 223, 0);
        color: black;
        border: none;
        cursor: pointer;
        margin-bottom: 0px;
    }
    .btn a{
        color: black;
    }
</style>
<body>
<form method="POST" enctype="multipart/form-data" class="box">
    <h2>ID</h2>
    <input type="number" name="id" placeholder="ID" value=<?php echo  isset($row['idagama']) ? $row['idagama'] : '';?> readonly>
    <h2>Nama</h2>
    <input type="text" name="namaA" placeholder="Nama" value=<?php echo  isset($row['nm_agama']) ? $row['nm_agama'] : '';?>>
    <h2>Tempat Lahir</h2>
    <input type="text" name="tplahir" placeholder="Tempat Lahir">
    <h2>Tanggal Lahir</h2>
    <input type="date" name="tglahir" placeholder="Tanggal Lahir">
    <h2>Alamat</h2>
    <input type="text" name="alamat" placeholder="Alamat">
    <h2>Hobi</h2>
    <input type="text" name="hobi" placeholder="Hobi">
    <h2>Cita-cita</h2>
    <input type="text" name="cita_cita" placeholder="Cita-cita">
    <h2>Jumlah Saudara</h2>
    <input type="number" name="jm_saudara" placeholder="Jumlah Saudara">
    <h2>ID Kelas</h2>
    <input type="number" name="idkelas" placeholder="ID Kelas">
    <h2>ID Agama</h2>
    <input type="number" name="idagama" placeholder="ID Agama">
    <br><br>
    <input type="submit" name="konfirmasi" value="Konfirmas" class="btn">
    <button class="btn"><a href="\biodatamelva\tampildata.php">Kembali</a></button>
</form>
</body>
<?php
include 'konek.php';
if (isset($_POST['konfirmasi'])){
    mysqli_query($koneksi, "update kelas set namakelas='$_POST[namak]', kompetensi='$_POST[kompetensi]', 
    tahun_pelajaran='$_POST[tp]', keterangan='$_POST[keterangan]' where id= $_GET[id]");
}
?>