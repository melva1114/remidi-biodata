<title>Edit Agama</title>
<?php 
include 'konek.php';
if (isset($_GET['id'])) {
    $data = mysqli_query($koneksi, "SELECT * FROM agama WHERE idagama = '$_GET[id]'");
    $row = mysqli_fetch_assoc($data);
}
?>
<style>
    *{
        text-decoration: none;
    }
    body{
        background-image: url(<?php echo "background.png";?>);
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
    }
     .bd{
        display: flex;
        height: 100vh;
        justify-content: center;
        align-items: center;
        background-color: rgb(148, 148, 148);
        font-family: Arial, Helvetica, sans-serif;
    }
    .box{
        width: 300px;
        min-height: 350px;
        border: 1px  rgb(253, 223, 0) solid;
        border-radius: 12px;
        background-color: purple;
        padding: 15px;
        box-sizing: border-box;
    }
    .box h2{
        margin-bottom: 20px;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
    }
    .input{
        width: 100%;
        padding: 10px;
        margin-bottom: 40px;
        box-sizing: border-box;
    }
    .btn{
        padding: 8px 15px;
        background-color: rgb(253, 223, 0);
        color: black;
        border: none;
        cursor: pointer;
        margin-bottom: 0px;
    }
    .btn a{
        color: black;
    }
</style>
<body>
<form method="POST" enctype="multipart/form-data" class="box">
    <h2>ID</h2>
    <input type="number" name="id" placeholder="ID" value=<?php echo  isset($row['idagama']) ? $row['idagama'] : '';?> readonly>
    <h2>Nama</h2>
    <input type="text" name="namaA" placeholder="Nama" value=<?php echo  isset($row['nm_agama']) ? $row['nm_agama'] : '';?>>
    <br><br>
    <input type="submit" name="konfirmasi" value="Konfirmas" class="btn">
    <button class="btn"><a href="\biodatamelva\tampildata.php">Kembali</a></button>
</form>
</body>
<?php
include 'konek.php';
if (isset($_POST['konfirmasi'])){
    mysqli_query($koneksi, "update biodata_agama set nm_agama='$_POST[namaA]' where idagama= $_GET[id]");
}
?>